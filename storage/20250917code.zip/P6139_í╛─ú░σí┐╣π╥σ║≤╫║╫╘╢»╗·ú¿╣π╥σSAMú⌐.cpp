#include<bits/stdc++.h>
#define ll long long
using namespace std;
constexpr int MN=2e6+15;
int n;

struct gySAM{
    int nxt[MN][26],fa[MN],pos[MN],len[MN],tot;
    vector<int> adj[MN];

    void init(){
        for(int i=0;i<=tot;i++){
            adj[i].clear();
            fa[i]=pos[i]=len[i]=0;
            memset(nxt[i],0,sizeof(nxt[i]));
        }
        tot=1;
    }

    gySAM(){
        init();
    }

    int newnode(){
        int cur=++tot;
        memset(nxt[cur],0,sizeof(nxt[cur]));
        return cur;
    }

    int clone(int from){
        int cur=++tot;
        fa[cur]=fa[from];
        memcpy(nxt[cur],nxt[from],sizeof(nxt[from]));
        return cur;
    }

    int extend(int c,int lst){
        if(nxt[lst][c]&&len[nxt[lst][c]]==len[lst]+1) return nxt[lst][c];
        int cur=newnode(),p=lst,flag=0,q,nq;
        len[cur]=len[p]+1;
        while(p&&!nxt[p][c]) nxt[p][c]=cur,p=fa[p];
        if(!p){
            fa[cur]=1;
        }else{
            q=nxt[p][c];
            if(len[q]==len[p]+1){
                fa[cur]=q;
            }else{
                if(p==lst) flag=1,cur=0,tot--;
                nq=clone(q);
                len[nq]=len[p]+1;
                fa[q]=fa[cur]=nq;
                while(p&&nxt[p][c]==q){
                    nxt[p][c]=nq;
                    p=fa[p];
                }
            }
        }
        return flag?nq:cur;
    }

    void inittree(){
        for(int i=2;i<=tot;i++){
            adj[fa[i]].push_back(i);
        }
    }

    void insert(string s){
        int len=s.length(),lst=1;
        s=" "+s;
        for(int i=1;i<=len;i++){
            lst=extend(s[i]-'a',lst);
        }
    }

}sam;


int main(){
    cin>>n;
    sam.init();
    for(int i=1;i<=n;i++){
        string s;
        cin>>s;
        sam.insert(s);
    }
    ll ans=0;
    for(int i=2;i<=sam.tot;i++){
        ans+=sam.len[i]-sam.len[sam.fa[i]];
    }
    cout<<ans<<"\n"<<sam.tot;
    return 0;
}
