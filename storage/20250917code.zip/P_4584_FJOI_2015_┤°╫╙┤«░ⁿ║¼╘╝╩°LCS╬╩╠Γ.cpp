#include<bits/stdc++.h>
#define int long long
using namespace std;
constexpr int MN=1e5+5;
struct Node{
    int posx,posy,posac,st;
    friend bool operator <(const Node &x,const Node &y){
        if(x.posx==y.posx){
            if(x.posy==y.posy){
                if(x.posac==y.posac){
                    return x.st<y.st;
                }
                return x.posac<y.posac;
            }
            return x.posy<y.posy;
        }
        return x.posx<y.posx;
    }
};
int n,m,K;
string x,y;
map<Node,int> mp;

struct ACAuto{
    int nxt[MN][58],fail[MN],end[MN],tot=1;
    void insert(string s,int st){
        int p=1;
        for(auto c:s){
            int k=c-'A';
            if(!nxt[p][k]) nxt[p][k]=++tot;
            p=nxt[p][k];
        }
        end[p]|=st;
    }
    void build(){
        queue<int> q;
        for(int i=0;i<58;i++) nxt[0][i]=1;
        q.push(1);
        while(!q.empty()){
            int u=q.front(); q.pop();
            end[u]|=end[fail[u]];
            for(int i=0;i<58;i++){
                if(!nxt[u][i]) nxt[u][i]=nxt[fail[u]][i];
                else fail[nxt[u][i]]=nxt[fail[u]][i],q.push(nxt[u][i]);
            }
        }
    }
}ac;

// 子序列自动机替代
int ch1[MN][58],ch2[MN][58];
void build_seq(const string &a,const string &b){
    for(int i=n;i;i--){
        memcpy(ch1[i],ch1[i+1],sizeof ch1[i]);
        ch1[i][a[i]-'A']=i+1;
    }
    for(int i=m;i;i--){
        memcpy(ch2[i],ch2[i+1],sizeof ch2[i]);
        ch2[i][b[i]-'A']=i+1;
    }
}

int dfs(int px,int py,int pac,int st){
    if(mp.count({px,py,pac,st})) return mp[{px,py,pac,st}];
    int ret=-1e9;
    if(st==(1<<K)-1) ret=0;
    for(int i=0;i<58;i++){
        int nx=ch1[px][i],ny=ch2[py][i],nac=ac.nxt[pac][i];
        if(nx&&ny) ret=max(ret,dfs(nx,ny,nac,st|ac.end[nac])+1);
    }
    return mp[{px,py,pac,st}]=ret;
}

signed main(){
    cin>>n>>m>>K;
    for(int i=1,qwq;i<=K;i++) cin>>qwq;
    cin>>x>>y; x=" "+x, y=" "+y;
    build_seq(x,y);
    for(int i=1;i<=K;i++){
        string s; cin>>s;
        ac.insert(s,1<<(i-1));
    }
    ac.build();
    cout<<dfs(1,1,1,0);
    return 0;
}
